package com.hitechbunny;

class Rollout {
    int freq;
    Double rlScore;
    Rollout[] peers;
    Double score;
}